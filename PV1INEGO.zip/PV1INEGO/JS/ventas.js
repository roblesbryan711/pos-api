/* campos:
id-venta
hora-venta
fecha-venta */
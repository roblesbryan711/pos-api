const productos = [
    [ "P001", "Manzana", 10.99 ],
    [ "P002", "Banana", 15.49 ],
    [ "P003", "Naranja", 7.99 ],
    [ "P004", "Pera", 12.50 ],
    [ "P005", "Uvas", 22.30 ],
    [ "P006", "Melón", 18.00 ],
    [ "P007", "Sandía", 9.75 ],
    [ "P008", "Piña", 25.99 ],
    [ "P009", "Mango", 30.00 ],
    [ "P010", "Fresas", 5.49 ],
];

/*
INSERT INTO productos (codigo, nombre_producto, precio) VALUES
('P001', 'Manzana', 10.99),
('P002', 'Banana', 15.49),
('P003', 'Naranja', 7.99),
('P004', 'Pera', 12.50),
('P005', 'Uvas', 22.30),
('P006', 'Melón', 18.00),
('P007', 'Sandía', 9.75),
('P008', 'Piña', 25.99),
('P009', 'Mango', 30.00),
('P010', 'Fresas', 5.49);

 */